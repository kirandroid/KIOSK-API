-- VArray
--	- Sequential data type
--	- Fixed size
--	- Ordered type data

--CREATE OR REPLACE TYPE variable_varray IS/AS VARRAY(n) of data_type;

CREATE OR REPLACE TYPE varray_test IS VARRAY(10) of NUMBER(10,0);
TYPE varray_test IS VARRAY(10) of NUMBER(10,0);

DECLARE 
   type varray_test IS VARRAY(10) of NUMBER(10,0);
   total NUMBER;  
BEGIN  
   num:= varray_test(1,6,3,65,21,45,21,63,47,26); 
   count_num := num.count; 
 
   FOR i in 1 .. count_num LOOP 
      dbms_output.put_line('i is : ' || num(i)); 
   END LOOP; 
END; 
/