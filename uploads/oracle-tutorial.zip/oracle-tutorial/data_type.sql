-- Data Type
/% Basic Types 
   - Character
	- CHAR(N) - Max length ( 2000 characters )
	- VARCHAR2(N)
	- NCHAR(N) 
		- Store National Language Specification (Unicode)
		- AL16UTF16
		- AL32UTF8
		- WE8MSWIN1252
	- NVARCHAR2(N)
   - Numeric Types:
   	- Number(Precision, Scale)
		- Precision => Total Width
		- Scale => total with after decimal point 
	- Float
	- Integer
	
    - Date Type
	- Date (DD-MM-YYYY)
		- Year Ranges from -4712 to 9999
		- Month (0 to 11)
		- Day (1 to 31)
	- Timestamp (YYYY-MM-DD HH-MI-SS-MS)
		- Hour (0 to 23)
		- Minute (0 to 59)
		- Second (0 to 59.9)
		TIMEZONE_HOUR
		TIMEZONE_MINUTE	
		TIMEZONE_REGION	
			- Select * 
			  from V$TIMEZONE_NAMES
			  where TZNAME like 'Asia/Kat%';
		TIMEZONE_ABBR	
    - Large Objects
	- CLOB (Character Large Object)
	- BLOB (Binary Large Object)
	- BFile (Binary File outside the database)/ Pointer
	- NLOB (NCHAR Large Object)

     - Subtype
	- SUBTYPE CUSTOMNAME IS DATE NOT NULL;
	  VARNM CUSTOMNAME := SYSDATE;  

      - NULL
      - BOOLEAN
%/ 

