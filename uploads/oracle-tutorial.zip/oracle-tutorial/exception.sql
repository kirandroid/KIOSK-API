SET SERVEROUTPUT ON

DECLARE
   reg_id usr_regions.region_id%type; 
   reg_name usr_regions.region_Name%type; 
BEGIN 
   SELECT  region_id, region_name INTO  reg_id, reg_name 
   FROM usr_regions 
   WHERE region_id = 4;  
   dbms_output.put_line (reg_id||  reg_name);  

EXCEPTION 
   WHEN no_data_found THEN 
      dbms_output.put_line('No regions found in the database'); 
   WHEN others THEN 
      dbms_output.put_line('General Error'); 
END; 
/

SET SERVEROUTPUT ON

DECLARE
   reg_id usr_regions.region_id%type; 
   reg_name usr_regions.region_Name%type;
   rc NUMBER; 
BEGIN 
   SELECT  region_id, region_name INTO  reg_id, reg_name 
   FROM usr_regions 
   WHERE region_id = 9;  
   
   if (sql%found)then
      rc := sql%rowcount;
      dbms_output.put_line (reg_id||  reg_name);
      dbms_output.put_line (rc||  'rows counted');
  else
      raise no_data_found;
  end if;
     
EXCEPTION 
   WHEN no_data_found THEN 
      dbms_output.put_line('No regions found in the database'); 
   WHEN others THEN 
      dbms_output.put_line('General Error'); 
END; 
/

-- User Defined exceptions


SET SERVEROUTPUT ON

DECLARE
   rc NUMBER;
   total NUMBER; 
   my_custom EXCEPTION;
BEGIN 
   SELECT count(*) INTO total 
   FROM usr_regions;  
  if (total < 10) then
    raise my_custom; 
  elsif (sql%found) then
      rc := sql%rowcount;
      dbms_output.put_line (rc||  'rows counted');
  else
      raise no_data_found;
  end if;
     
EXCEPTION
   WHEN my_custom THEN 
      dbms_output.put_line('Not Enough rows in the table'); 
   WHEN no_data_found THEN 
      dbms_output.put_line('No regions found in the database'); 
   WHEN others THEN 
      dbms_output.put_line('General Error'); 
END; 
/


