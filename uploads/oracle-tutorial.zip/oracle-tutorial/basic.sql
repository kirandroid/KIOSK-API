-- Basic transactions
-DECLARE
-   <declare statements>
-BEGIN
-   <begin transactions or statements>
-EXCEPTION
-   <Exceptions >
-END;
-/

SET SERVEROUTPUT ON
DECLARE
   first_name VARCHAR2(20) DEFAULT "Larry";
   mid_name CHAR(10) := '';
   last_name VARCHAR2(20);
BEGIN
   last_name := "Ellison";
   dbms_output.put_line(first_name||' '||mid_name||' '||last_name); 
END;
/

