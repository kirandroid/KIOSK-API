SET SERVEROUTPUT ON
DECLARE
   first_name VARCHAR2(20) DEFAULT "Larry";
   mid_name CHAR(10) := '';
   last_name VARCHAR2(20);
   pi CONSTANT NUMBER(6,4) := 3.1415; 
	-- Constant 
BEGIN
   last_name := "Ellison";
   dbms_output.put_line(first_name||' '||mid_name||' '||last_name); 
END;
/

