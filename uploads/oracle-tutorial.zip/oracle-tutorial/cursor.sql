-- Cursor
	-- Pointer
	-- Holds the context area
	-- Rows hold by cursor are called active set

	-- Types
		-- Implicit Cursor
		-- Explicit Cursor

-- Implicit Cursor

	-- %FOUND
		-- True if rows are affected
	-- %NOTFOUND
		-- True if no rows are affected
	-- %ISOPEN
		-- Its False by default in the implicit cursor
	-- %ROWCOUNT 
		-- No. of rows affected

DECLARE  
   	affected_rows NUMBER; 
BEGIN 
   	UPDATE USR_EMPLOYEES 
    SET MANAGER_ID = 4
    WHERE EMPLOYEE_ID = 5;

   	IF sql%FOUND THEN 
		affected_rows := sql%ROWCOUNT;
      		dbms_output.put_line(affected_rows || ' has been affected'); 
  	ELSIF sql%NOTFOUND THEN 
      		dbms_output.put_line('No rows are affected'); 
   END IF;  
END; 
/      

-- Explicit Cursor

	--Declare the cursor
	--Open the cursor	
	--Fetch the cursor	
	--Close the cursor

DECLARE  
   	reg_id usr_regions.region_id%type;
    	reg_name usr_regions.region_name%type;
    	affected_rows NUMBER;  
    	CURSOR reg_data IS 
     	 Select region_id,region_name FROM USR_REGIONS;
BEGIN 
   	OPEN reg_data;
    	IF reg_data%NOTFOUND THEN
      		dbms_output.put_line('No data found');
    	Else	 
		LOOP
			FETCH reg_data into reg_id, reg_name;
        			EXIT WHEN reg_data%notfound;
			dbms_output.put_line(reg_id || reg_name); 
     		END LOOP;   
    	CLOSE reg_data;
   	END IF;
END; 
/    