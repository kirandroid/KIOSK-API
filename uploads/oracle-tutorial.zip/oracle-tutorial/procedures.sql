SET SERVEROUTPUT ON
-- Procedure

-- Basic Procedure

CREATE OR REPLACE PROCEDURE hello_oracle 
IS
BEGIN
	dbms_output.put_line('Hello Oracle');
END;
/


-- Procedure with parameter

-- IN parameter

CREATE OR REPLACE PROCEDURE update_manager_id(id IN NUMBER)
IS
  num NUMBER;  
BEGIN
	SELECT MANAGER_ID
  	INTO num
	FROM USR_EMPLOYEES
	WHERE EMPLOYEE_ID = id;

  	dbms_output.put_line(num);

	UPDATE USR_EMPLOYEES
	SET MANAGER_ID = 4
	WHERE EMPLOYEE_ID = id;

	SELECT MANAGER_ID
  INTO num
	FROM USR_EMPLOYEES
	WHERE EMPLOYEE_ID = id;
  dbms_output.put_line(num);
  
END;
/
BEGIN
-- Positional Substitution
update_manager_id(5);
END;
/


SET SERVEROUTPUT ON
CREATE OR REPLACE PROCEDURE add_num(firstn IN NUMBER, secondn IN NUMBER, output OUT NUMBER)
IS
BEGIN
	output := firstn + secondn;
END;
/   

DECLARE
  num1 NUMBER := 45;
	num2 NUMBER := 54;
	sum_num NUMBER;	
BEGIN
-- Mixed Substitution
 	add_num(num1, secondn=>num2,output=>sum_num);
	dbms_output.put_line('The value of sum is '||sum_num);
END;
/


SET SERVEROUTPUT ON
CREATE OR REPLACE PROCEDURE cube_val(number1 IN OUT NUMBER)
IS
BEGIN
	number1 := power(number1, 3);
END;
/   

DECLARE
	cube_num NUMBER := 4;	
BEGIN
--Named Substitution
 	cube_val(number=>cube_num);
	dbms_output.put_line('The value of sum is '||cube_num);
END;
/

	          
	                                                                                                                                                                                                                                                                                                                                                              