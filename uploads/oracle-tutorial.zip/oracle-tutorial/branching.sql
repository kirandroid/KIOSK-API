
-- IF-THEN branch
SET SERVEROUTPUT ON
DECLARE
   num NUMBER(30,0) := 42;
BEGIN
   IF (num <> 50) THEN
	dbms_output.put_line(num || ' is not equal to 50.'); 
   END IF;
END;
/

-- IF-THEN-ELSE branch
SET SERVEROUTPUT ON
DECLARE
   num NUMBER(30,0) := 42;
BEGIN
   IF (mod(num,2) = 0) THEN
	dbms_output.put_line(num || ' is even number'); 
   ELSE
	dbms_output.put_line(num || ' is odd number');
   END IF;
END;
/

-- IF-THEN-ELSIF branch
SET SERVEROUTPUT ON
DECLARE
   color VARCHAR2(15) := 'cyan';
BEGIN
   IF (color = 'red') THEN
	dbms_output.put_line(color || ' is red'); 
   ELSIF (color = 'blue') THEN
	dbms_output.put_line(color || ' is blue');
   ELSIF (color = 'black') THEN
	dbms_output.put_line(color || ' is black');
   ELSIF (color = 'orange') THEN
	dbms_output.put_line(color || ' is orange');
   ELSE
	dbms_output.put_line(color || ' is cyan');
   END IF;
END;
/

-- Case Statement
SET SERVEROUTPUT ON
DECLARE
   vowel CHAR(1) := 'O';
BEGIN
case vowel
   WHEN vowel = 'A' THEN 
	dbms_output.put_line(vowel || ' is A'); 
   WHEN vowel = 'E' THEN 
	dbms_output.put_line(vowel || ' is E'); 
   WHEN vowel = 'I' THEN 
	dbms_output.put_line(vowel || ' is I'); 
   WHEN vowel = 'O' THEN 
	dbms_output.put_line(vowel || ' is O'); 
   ELSE 
	dbms_output.put_line(vowel || ' is U'); 

-- Searched Case Statement
SET SERVEROUTPUT ON
DECLARE
   vowel CHAR(1) := 'O';
BEGIN
case 
   WHEN vowel = 'A' THEN 
	dbms_output.put_line(vowel || ' is A'); 
   WHEN vowel = 'E' THEN 
	dbms_output.put_line(vowel || ' is E'); 
   WHEN vowel = 'I' THEN 
	dbms_output.put_line(vowel || ' is I'); 
   WHEN vowel = 'O' THEN 
	dbms_output.put_line(vowel || ' is O'); 
   ELSE 
	dbms_output.put_line(vowel || ' is U'); 


-- NESTED IF-THEN branch
SET SERVEROUTPUT ON
DECLARE
   num NUMBER(30,0) := 6;
BEGIN
   IF (mod(num,2) = 0) THEN
	if (mod(num,3) = 0) THEN
		dbms_output.put_line(num || ' is divided by both 2 and 3'); 
	END IF;
   ELSE
	dbms_output.put_line(num || ' is odd number');
   END IF;
END;
/

