SET SERVEROUTPUT ON
CREATE OR REPLACE FUNCTION fn_add_num(firstn IN NUMBER, secondn IN NUMBER) 
RETURN NUMBER
IS
	temp NUMBER;
BEGIN
	temp := firstn + secondn;
	RETURN temp;
END;
/   

DECLARE
  num1 NUMBER := 45;
	num2 NUMBER := 54;
	sum_num NUMBER;	
BEGIN
 	sum_num := fn_add_num(num1, num2);
	dbms_output.put_line('The value of sum is '||sum_num);
END;
/

SET SERVEROUTPUT ON
CREATE OR REPLACE FUNCTION fn_cube_val(number1 IN OUT NUMBER)
RETURN NUMBER
IS
BEGIN
	number1 := power(number1, 3);
	RETURN number1;
END;
/   

DECLARE
	cube_num NUMBER := 4;	
BEGIN
 	cube_num := fn_cube_val(number1=>cube_num);
	dbms_output.put_line('The value of sum is '||cube_num);
END;
/

	          
	                                                                                                                                                                                                                                                                                                                                                              