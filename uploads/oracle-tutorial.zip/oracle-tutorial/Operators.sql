-- Operators
/%
  - Arithematic Operator
	-> +/-*
	-> mod(a,b)
	-> power(a,b)

   - Comparision Operator
	- >/>=
	- </<=
	- ~=/!=/<>
	- =
	- like
	- between
	- in
	- is null

    - Logical operator
	- and
	- or
	- not









%/