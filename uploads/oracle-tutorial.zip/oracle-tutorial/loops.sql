-- Basic Loop with exit
SET SERVEROUTPUT ON
DECLARE
   num NUMBER(10,0) := 1;
BEGIN
   LOOP
	dbms_output.put_line('The value of num is '||' '|| num);
	num := num + 1;
	IF (num > 10) THEN
		exit;	
	END IF;	
   END LOOP; 
END;
/


-- Basic Loop with exit when
SET SERVEROUTPUT ON
DECLARE
   num NUMBER(10,0) := 1;
BEGIN
   LOOP
	dbms_output.put_line('The value of num is '||' '|| num);
	num := num + 1;
	exit when num > 10;		
   END LOOP; 
END;
/

-- While loop
SET SERVEROUTPUT ON
DECLARE
   num NUMBER(10,0) := 1;
BEGIN
   while (a <= 10) LOOP
	dbms_output.put_line('The value of num is '||' '|| num);
	num := num + 1;		
   END LOOP; 
END;
/

-- For loop
SET SERVEROUTPUT ON
DECLARE
   num NUMBER(10,0) := 1;
BEGIN
   for num in 1..10 LOOP
	dbms_output.put_line('The value of num is '||' '|| num);
	num := num + 1;		
   END LOOP; 
   for num in REVERSE 1..10 LOOP
	dbms_output.put_line('The value of num is '||' '|| num);
	num := num + 1;		
   END LOOP;  
END;
/

